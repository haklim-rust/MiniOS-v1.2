clang -target i386-pc-none-elf -ffreestanding -fno-builtin -c kernel.c -o kernel.o

# boot compile

nasm -f elf32 boot.asm -o boot.o

# linker

ld.lld -m elf_i386 -T link.ld -o kernel.bin kernel.o boot.o

# kernel compile

clang -target i386-pc-none-elf -ffreestanding -fno-builtin -c kernel.c -o kernel.o
