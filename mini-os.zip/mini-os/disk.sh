# Sektor 2: Daftar file (untuk ls)
echo "bin/  flag.txt  readme.txt" > files.txt

# Sektor 3: Isi file (untuk cat)
echo "Halo Bang! Ini isi file dari sektor 3 harddisk virtual kamu." > content.txt

# Gabungkan ke image
dd if=/dev/zero of=harddisk.img bs=1M count=1
dd if=files.txt of=harddisk.img bs=512 seek=2 conv=notrunc
dd if=content.txt of=harddisk.img bs=512 seek=3 conv=notrunc
