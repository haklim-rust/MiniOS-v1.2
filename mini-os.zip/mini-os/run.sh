qemu-system-i386 -kernel kernel.bin -hda harddisk.img 
