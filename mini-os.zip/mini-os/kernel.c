typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

char* video_mem = (char*)0xB8000;
int cursor_x = 0;
int cursor_y = 0;
char input_buffer[64];
int input_ptr = 0;
char current_dir[32] = "/"; // State untuk 'cd'

// --- UTILS ---
void* memcpy(void* dest, const void* src, int n) {
    char* d = (char*)dest;
    const char* s = (const char*)src;
    while (n--) *d++ = *s++;
    return dest;
}

int strcmp(char* s1, char* s2) {
    while (*s1 && (*s1 == *s2)) { s1++; s2++; }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void memset(char* dest, char val, int len) {
    for (int i = 0; i < len; i++) dest[i] = val;
}

// --- I/O PORTS ---
unsigned char inb(unsigned short port) {
    unsigned char ret;
    __asm__ __volatile__ ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

void outb(unsigned short port, unsigned char val) {
    __asm__ __volatile__ ("outb %0, %1" : : "a"(val), "Nd"(port));
}

void outw(unsigned short port, unsigned short val) {
    __asm__ __volatile__ ("outw %0, %1" : : "a"(val), "Nd"(port));
}

// --- DISPLAY ---
void update_cursor() {
    unsigned short pos = cursor_y * 80 + cursor_x;
    outb(0x3D4, 0x0F); outb(0x3D5, (uint8_t)(pos & 0xFF));
    outb(0x3D4, 0x0E); outb(0x3D5, (uint8_t)((pos >> 8) & 0xFF));
}

void put_char(char c, char color) {
    if (c == '\n') {
        cursor_x = 0; cursor_y++;
    } else if (c == '\b') {
        // Logika Backspace: jangan hapus prompt dinamis
        int prompt_len = 3 + 1; // "~ # " + spasi
        for(int i=0; current_dir[i]; i++) prompt_len++; 
        
        if (cursor_x > prompt_len) {
            cursor_x--;
            video_mem[(cursor_y * 80 + cursor_x) * 2] = ' ';
            video_mem[(cursor_y * 80 + cursor_x) * 2 + 1] = 0x07;
        }
    } else {
        video_mem[(cursor_y * 80 + cursor_x) * 2] = c;
        video_mem[(cursor_y * 80 + cursor_x) * 2 + 1] = color;
        cursor_x++;
    }
    if (cursor_x >= 80) { cursor_x = 0; cursor_y++; }
    update_cursor();
}

void print(char* str, char color) {
    while (*str) put_char(*str++, color);
}

void print_prompt() {
    print("~", 0x0A); // Hijau
    print(current_dir, 0x0B); // Cyan untuk folder
    print(" # ", 0x0A);
}

// --- COMMANDS ---
void execute_command() {
    print("\n", 0x07);
    
    if (strcmp(input_buffer, "help") == 0) {
        print("Daftar Perintah:\n", 0x0E);
        print("ls, cat, cd, mkdir, rm, free -h, clear, reboot, shutdown, whoami", 0x07);
    } 
    else if (strcmp(input_buffer, "ls") == 0) {
        print("bin/  etc/  root/  flag.txt", 0x0B);
    } 
    else if (strcmp(input_buffer, "whoami") == 0) {
        print("root", 0x0F);
    }
    else if (strcmp(input_buffer, "free -h") == 0) {
        print("Mem: 128M  Used: 440K  Free: 127.5M", 0x0E);
    }
    else if (strcmp(input_buffer, "clear") == 0) {
        for (int i = 0; i < 80 * 25 * 2; i += 2) { video_mem[i] = ' '; video_mem[i+1] = 0x07; }
        cursor_x = 0; cursor_y = 0;
    }
    else if (strcmp(input_buffer, "mkdir") == 0) {
        print("Error: Read-only file system.", 0x0C);
    }
    else if (strcmp(input_buffer, "rm -f") == 0 || strcmp(input_buffer, "rm -rf") == 0) {
        print("rm: cannot remove: Permission denied (Read-only)", 0x0C);
    }
    else if (strcmp(input_buffer, "cd ..") == 0) {
        memcpy(current_dir, "/", 2);
    }
    else if (strcmp(input_buffer, "cd bin") == 0) {
        memcpy(current_dir, "/bin", 5);
    }
    else if (strcmp(input_buffer, "shutdown") == 0) {
        outw(0x604, 0x2000);
    }
    else if (strcmp(input_buffer, "reboot") == 0) {
        outb(0x64, 0xFE);
    }
    else if (input_buffer[0] != 0) {
        print("sh: command not found: ", 0x0C);
        print(input_buffer, 0x0C);
    }

    if (strcmp(input_buffer, "clear") != 0) {
        print("\n", 0x07);
        print_prompt();
    } else {
        print_prompt();
    }
    
    memset(input_buffer, 0, 64);
    input_ptr = 0;
}

// --- KEYBOARD ---
char get_ascii(uint8_t scancode) {
    static const char map[] = {
        0,0,'1','2','3','4','5','6','7','8','9','0','-','=',0,0,
        'q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
        'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\',
        'z','x','c','v','b','n','m',',','.','/',0,'*',0,' '
    };
    if (scancode == 0x0E) return '\b';
    if (scancode < sizeof(map)) return map[scancode];
    return 0;
}

void main() {
    for (int i = 0; i < 80 * 25 * 2; i += 2) { video_mem[i] = ' '; video_mem[i+1] = 0x07; }
    print("MiniOS Shell v1.2 (Type 'help' for commands)\n", 0x0E);
    print_prompt();
    update_cursor();

    while(1) {
        if (inb(0x64) & 0x1) {
            uint8_t sc = inb(0x60);
            if (!(sc & 0x80)) {
                char c = get_ascii(sc);
                if (c == '\n') {
                    execute_command();
                } else if (c == '\b') {
                    if (input_ptr > 0) {
                        input_ptr--;
                        input_buffer[input_ptr] = 0;
                        put_char('\b', 0x07);
                    }
                } else if (c > 0 && input_ptr < 63) {
                    put_char(c, 0x0F);
                    input_buffer[input_ptr++] = c;
                }
            }
        }
    }
}
