[bits 32]

; =========================
; MULTIBOOT HEADER (GRUB)
; =========================
section .multiboot
    align 4
    dd 0x1BADB002              ; magic
    dd 0x00                    ; flags
    dd -(0x1BADB002 + 0x00)    ; checksum

; =========================
; STACK (8KB)
; =========================
section .bss
    align 16
stack_bottom:
    resb 8192                  ; 8KB stack
stack_top:

; =========================
; CODE
; =========================
section .text
global _start
extern main

_start:
    cli                     ; disable interrupt (amanin awal)

    mov esp, stack_top      ; setup stack (WAJIB)

    ; kalau mau ambil multiboot info dari GRUB
    ; ebx = pointer ke multiboot info
    push ebx

    call main               ; masuk ke kernel C kamu

.hang:
    hlt                     ; hemat CPU
    jmp .hang               ; loop selamanya