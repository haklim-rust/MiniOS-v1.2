
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

// ================= GLOBAL =================
char* video_mem = (char*)0xB8000;
int cursor_x = 0; int cursor_y = 0;

char input_buffer[64]; int input_ptr = 0;

char current_dir[32] = "/";

int is_shift_pressed = 0;
int is_caps_lock = 0;

char last_status_col = 0x0A;

// ================= FAT12 =================
struct dir_entry {
    char name[8];
    char ext[3];
    uint8_t attr;
    uint8_t reserved[10];
    uint16_t time;
    uint16_t date;
    uint16_t first_cluster;
    uint32_t size;
};

struct dir_entry root[224];

// ================= UTILS =================
int strcmp(char* s1, char* s2) {
    while(*s1 && (*s1 == *s2)) { s1++; s2++; }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void memset(char* dest, char val, int len) {
    for(int i=0; i<len; i++) dest[i]=val;
}

// ================= I/O =================
unsigned char inb(unsigned short p) {
    unsigned char r;
    __asm__ __volatile__ ("inb %1, %0" : "=a"(r) : "Nd"(p));
    return r;
}

void outb(unsigned short p, unsigned char v) {
    __asm__ __volatile__ ("outb %0, %1" : : "a"(v), "Nd"(p));
}

void outw(unsigned short p, unsigned short v) {
    __asm__ __volatile__ ("outw %0, %1" : : "a"(v), "Nd"(p));
}

unsigned short inw(unsigned short p) {
    unsigned short r;
    __asm__ __volatile__ ("inw %1, %0" : "=a"(r) : "d"(p));
    return r;
}

// ================= RTC =================
unsigned char get_rtc(int reg) {
    outb(0x70, reg);
    return inb(0x71);
}

int bcd_to_bin(unsigned char b) {
    return ((b/16)*10) + (b%16);
}

// ================= DISK =================
void read_sector(uint32_t lba, uint16_t* buf) {
    outb(0x1F6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(0x1F2, 1);
    outb(0x1F3, (uint8_t)lba);
    outb(0x1F4, (uint8_t)(lba >> 8));
    outb(0x1F5, (uint8_t)(lba >> 16));
    outb(0x1F7, 0x20);

    while ((inb(0x1F7) & 0x88) != 0x08);

    for (int i = 0; i < 256; i++) {
        buf[i] = inw(0x1F0);
    }
}

// ================= DISPLAY =================
void update_cursor() { 
    unsigned short p = cursor_y * 80 + cursor_x;
    outb(0x3D4, 0x0F); outb(0x3D5, (uint8_t)(p & 0xFF));
    outb(0x3D4, 0x0E); outb(0x3D5, (uint8_t)((p >> 8) & 0xFF));
}

void clear_screen() {
    for(int i=0; i<80*25*2; i+=2) {
        video_mem[i]=' ';
        video_mem[i+1]=0x07;
    }
    cursor_x = 0; cursor_y = 0; 
    update_cursor();
}

void put_char(char c, char col) {
    if(c == '\n') { cursor_x = 0; cursor_y++; }
    else if(c == '\b') {
        if(cursor_x > 0) cursor_x--;
        video_mem[(cursor_y*80+cursor_x)*2] = ' ';
        video_mem[(cursor_y*80+cursor_x)*2+1] = 0x07;
    }
    else {
        video_mem[(cursor_y*80+cursor_x)*2] = c;
        video_mem[(cursor_y*80+cursor_x)*2+1] = col;
        cursor_x++;
    }

    if(cursor_x >= 80) { cursor_x = 0; cursor_y++; }
    update_cursor();
}

void print(char* s, char c) { while(*s) put_char(*s++, c); }

// ================= FAT =================
void load_root() {
    uint16_t* buf = (uint16_t*)root;
    for(int i=0; i<14; i++) {
        read_sector(19 + i, buf + (i * 256));
    }
}

int match_name(struct dir_entry* e, char* name) {
    char fname[11];
    int i=0, j=0;

    while(name[i] && name[i] != '.') fname[j++] = name[i++];
    while(j < 8) fname[j++] = ' ';

    if(name[i] == '.') i++;

    while(name[i]) fname[j++] = name[i++];
    while(j < 11) fname[j++] = ' ';

    for(int k=0; k<11; k++) {
        if(e->name[k] != fname[k]) return 0;
    }
    return 1;
}

void read_file(char* name) {
    load_root();

    for(int i=0; i<224; i++) {
        if(root[i].name[0] == 0) break;

        if(match_name(&root[i], name)) {
            uint16_t cluster = root[i].first_cluster;
            uint32_t size = root[i].size;

            uint16_t buf[256];
            uint32_t lba = 33 + (cluster - 2);

            read_sector(lba, buf);

            for(uint32_t j=0; j<size; j++) {
                char c = ((char*)buf)[j];
                if(c == 0) break;
                put_char(c, 0x0F);
            }
            return;
        }
    }

    print("File not found", 0x0C);
}

// ================= COMMAND =================
void execute_command() {
    print("\n", 0x07);
    last_status_col = 0x0A;

    if (strcmp(input_buffer, "help") == 0) {
        print("ls, cat <file>, date, uname, uptime, sysinfo, whoami, clear, shutdown", 0x0E);
    }
    else if (strcmp(input_buffer, "ls") == 0) {
        print("flag.txt", 0x0B);
    }
    else if (input_buffer[0]=='c' && input_buffer[1]=='a' && input_buffer[2]=='t' && input_buffer[3]==' ') {
        read_file(input_buffer + 4);
    }
    else if (strcmp(input_buffer, "date") == 0) {
        int dy=bcd_to_bin(get_rtc(7)), mo=bcd_to_bin(get_rtc(8)), yr=bcd_to_bin(get_rtc(9));
        print("Date: ",0x0F);
        put_char((dy/10)+'0',0x0F); put_char((dy%10)+'0',0x0F);
        print("/",0x0F);
        put_char((mo/10)+'0',0x0F); put_char((mo%10)+'0',0x0F);
        print("/20",0x0F);
        put_char((yr/10)+'0',0x0F); put_char((yr%10)+'0',0x0F);
    }
    else if (strcmp(input_buffer, "uname") == 0) {
        print("MiniOS mshell", 0x0F);
    }
    else if (strcmp(input_buffer, "uptime") == 0) {
        print("Up via RTC", 0x0A);
    }
    else if (strcmp(input_buffer, "sysinfo") == 0) {
        print("MiniOS + FAT12", 0x0B);
    }
    else if (strcmp(input_buffer, "whoami") == 0) {
        print("root", 0x0F);
    }
    else if (strcmp(input_buffer, "clear") == 0) {
        clear_screen();
    }
    else if (strcmp(input_buffer, "shutdown") == 0) {
        print("Power off...",0x0C);
        outw(0x604, 0x2000);
    }
    else if (input_buffer[0] != 0) {
        print("mshell: not found: ", 0x0C);
        print(input_buffer, 0x0C);
        last_status_col = 0x0C;
    }

    print("\nmshell:", 0x0A);
    print(current_dir, 0x0B);
    print(" $ ", last_status_col);

    memset(input_buffer, 0, 64);
    input_ptr = 0;
}

// ================= KEYBOARD =================
char get_ascii(uint8_t sc) {
    static const char low[] = {
        0,27,'1','2','3','4','5','6','7','8','9','0','-','=',0x08,0,
        'q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
        'a','s','d','f','g','h','j','k','l',';','\'','`',0,
        '\\','z','x','c','v','b','n','m',',','.','/',0,'*',0,' '
    };

    static const char upp[] = {
        0,27,'!','@','#','$','%','^','&','*','(',')','_','+',0x08,0,
        'Q','W','E','R','T','Y','U','I','O','P','{','}','\n',0,
        'A','S','D','F','G','H','J','K','L',':','"','~',0,
        '|','Z','X','C','V','B','N','M','<','>','?',0,'*',0,' '
    };

    if (sc >= 58) return 0;

    char c = is_shift_pressed ? upp[sc] : low[sc];

    if(is_caps_lock && c >= 'a' && c <= 'z') return c - 32;
    if(is_caps_lock && c >= 'A' && c <= 'Z' && is_shift_pressed) return c + 32;

    return c;
}

// ================= MAIN =================
void main() {
    clear_screen();

    print("mshell:",0x0A);
    print(current_dir,0x0B);
    print(" $ ",0x0A);

    while(1) {
        if(inb(0x64)&1) {
            uint8_t sc = inb(0x60);

            if (sc == 0x2A || sc == 0x36) is_shift_pressed = 1;
            else if (sc == 0xAA || sc == 0xB6) is_shift_pressed = 0;
            else if (sc == 0x3A) is_caps_lock = !is_caps_lock;

            else if (!(sc & 0x80)) {
                if(sc == 0x1C) {
                    execute_command();
                }
                else if(sc == 0x0E) {
                    if(input_ptr > 0) {
                        input_ptr--;
                        input_buffer[input_ptr] = 0;
                        put_char('\b',0x07);
                    }
                }
                else {
                    char c = get_ascii(sc);
                    if(c >= 32 && c <= 126 && input_ptr < 63) {
                        put_char(c,0x0F);
                        input_buffer[input_ptr++] = c;
                    }
                }
            }
        }
    }
}